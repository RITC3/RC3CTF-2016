import random
from flask import Flask, render_template, send_from_directory, jsonify

application = Flask(__name__)


@application.route('/')
def hello_world():
    return render_template("index.html", title="Nothing to see here")


@application.route('/and-so-it-begins')
def challenge_01():
    return render_template("01-and-so-it-begins.html", title="And So It Begins...")


@application.route('/sam-tso-sends-his-regards')
def challenge_02():
    return render_template("02-sam-tso-sends-his-regards.html", title="Listen Carefully, Agent.")

@application.route('/track/next/<track>')
def challenge_02_track_api(track):
    if track == "start":
        current = random.randint(0, 9)
    else:
        skip = 0
        for i in range(len(track)):
            if track[i].isdigit():
                skip = i + int(track[i])
                break

        current = int(track[skip])
        print("currently on %d" % current)

    skip = 0
    new_hash = "%032x" % random.getrandbits(128)
    for i in range(len(new_hash)):
        if new_hash[i].isdigit():
            skip = i + int(new_hash[i])
            break
    next_track_id = (current + 1) % 10
    new_hash = new_hash[:skip] + str(next_track_id) + new_hash[skip + 1:]
    print("sending to %s (%d)" % (new_hash, next_track_id))

    return jsonify(track="%s" % new_hash)


@application.route('/track/<track>')
def challenge_02_tracks(track):
    skip = 0
    for i in range(len(track)):
        if track[i].isdigit():
            skip = i + int(track[i])
            break

    current = int(track[skip])
    print("sending file f%d.mp3" % current)
    return send_from_directory('static/tracks/', 'f%d.mp3' % current)


@application.route('/its-just-a-one-time-thing')
def challenge_03():
    return render_template('03-its-just-a-one-time-thing.html', title='Top 59 Songs to Spy To')

@application.route('/one-cipher-plox')
def challenge_04():
    return render_template('04-one-cipher-plox.html', title='Well, since you asked so nicely...')
@application.errorhandler(404)
def error(e):
    return render_template("index.html", title="Guessing will get you nowhere...")

if __name__ == '__main__':
    print("starting standalone server")
    application.run()
